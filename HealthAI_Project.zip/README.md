# HealthAI: Chest X-ray Classification using CNN

An educational AI healthcare project that uses a Convolutional
Neural Network (CNN) built with PyTorch to classify chest X-ray
images into Normal or Pneumonia categories.

## Features

- CNN-based image classification
- Interactive Gradio dashboard with a dark theme
- X-ray image upload and experimental model output
- Test-set evaluation metrics
- Confusion matrix information

## Technologies

- Python
- PyTorch and Torchvision
- MedMNIST / PneumoniaMNIST
- Gradio
- Scikit-learn
- Matplotlib

## Model Evaluation

Results from this project's held-out test evaluation:

- **Accuracy:** 87.82%
- **Precision:** 85.36%
- **Recall:** 97.18%
- **F1-score:** 90.89%
- **Test images:** 624

These metrics describe this particular experimental model and
dataset. They do not establish clinical performance.

## Run Locally

1. Install Python 3.10 or later.
2. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

3. Ensure `chest_xray_cnn.pth` and `model_metrics.json`
   are in the project directory.
4. Start the dashboard:

   ```bash
   python app.py
   ```

## Limitations and Responsible Use

This is an educational prototype using low-resolution images.
It has not been clinically validated and must not be used to
diagnose, screen, or make treatment decisions for patients.
Model outputs may be wrong.

## Project Structure

- `app.py` - model and Gradio dashboard
- `chest_xray_cnn.pth` - trained model weights
- `model_metrics.json` - test evaluation results
- `requirements.txt` - Python dependencies
- `README.md` - project documentation

## Author

Created as an AI/ML learning project.
