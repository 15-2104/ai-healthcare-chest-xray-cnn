import json
import torch
import torch.nn as nn
import gradio as gr
import matplotlib.pyplot as plt

from torchvision import transforms


class ChestXrayCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(1, 16, 3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(16, 32, 3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2)
        )
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(32 * 7 * 7, 64),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(64, 1)
        )

    def forward(self, x):
        return self.classifier(self.features(x))


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = ChestXrayCNN().to(device)
model.load_state_dict(
    torch.load("chest_xray_cnn.pth", map_location=device)
)
model.eval()

transform = transforms.Compose([
    transforms.Resize((28, 28)),
    transforms.ToTensor(),
    transforms.Normalize([0.5], [0.5])
])

with open("model_metrics.json") as f:
    metrics = json.load(f)


def predict_xray(image):
    if image is None:
        return "Upload an image first.", None

    tensor = transform(image.convert("L")).unsqueeze(0).to(device)

    with torch.no_grad():
        score = torch.sigmoid(model(tensor)).item()

    label = "Pneumonia" if score >= 0.5 else "Normal"
    result = (
        f"Experimental model output: {label}\n"
        f"Model score for Pneumonia: {score:.1%}\n\n"
        "This result is not a medical diagnosis."
    )
    return result, {"Normal": 1 - score, "Pneumonia": score}


css = """
.gradio-container {
    background: #0b1120 !important;
    color: #e5e7eb !important;
}
.panel {
    background: #111c30;
    border: 1px solid #263650;
    border-radius: 16px;
    padding: 18px;
}
"""

with gr.Blocks(
    theme=gr.themes.Base(
        primary_hue="blue",
        neutral_hue="slate"
    ),
    css=css,
    title="HealthAI Dashboard"
) as demo:

    gr.Markdown("""
    # 🩻 HealthAI Dashboard
    ### Chest X-ray Classification · CNN Research Prototype

    **Educational use only — not for medical diagnosis or treatment.**
    """)

    with gr.Row():
        with gr.Column():
            gr.Markdown("### 📊 Model Performance")
            gr.Markdown(
                f"**Test accuracy:** {metrics['accuracy']}%  \n"
                f"**Precision:** {metrics['precision']}%  \n"
                f"**Recall:** {metrics['recall']}%  \n"
                f"**F1-score:** {metrics['f1_score']}%  \n"
                f"**Test images:** {metrics['test_samples']}"
            )

            gr.Markdown("### 🧠 Model Information")
            gr.Markdown(
                "- Architecture: Convolutional Neural Network (CNN)\n"
                "- Framework: PyTorch\n"
                "- Input size: 28 × 28 grayscale\n"
                "- Dataset: PneumoniaMNIST"
            )

        with gr.Column():
            gr.Markdown("### 🔍 X-ray Analysis")
            image_input = gr.Image(
                type="pil", label="Upload sample X-ray"
            )
            analyze_btn = gr.Button(
                "Analyze Image", variant="primary"
            )
            output_text = gr.Textbox(
                label="Experimental result", lines=4
            )
            output_scores = gr.Label(
                label="Model scores", num_top_classes=2
            )

            analyze_btn.click(
                fn=predict_xray,
                inputs=image_input,
                outputs=[output_text, output_scores]
            )

    gr.Markdown("""
    ---
    **Limitations:** This prototype uses low-resolution images and has
    not been clinically validated. Predictions must not guide patient care.
    """)

demo.launch(share=True)
